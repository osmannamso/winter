export interface Company {
  id: number;
  name: string;
  requisites: string;
}
