export interface Notification {
  id: number;
  body: string;
  created_at: string;
  is_viewed: boolean;
  title: string;
  trip_request: number;
}
