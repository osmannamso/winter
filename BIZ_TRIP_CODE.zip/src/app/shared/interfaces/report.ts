export interface Report {
  amount: number;
  created_at: string;
  id: number;
  invoice: string;
  invoice_pdf: string;
  operation_type: string;
  route_sheet_pdf: string;
}
