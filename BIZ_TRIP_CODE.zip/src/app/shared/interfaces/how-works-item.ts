export interface HowWorksItem {
  image: string;
  text: string;
}
