export interface Reviewer {
  name: string;
  avatar: string;
  text: string;
  logo: string;
  job: string;
}
