export const TOKEN_KEY = 'token';
export const COMPANY_KEY = 'company';
export const USER_KEY = 'user';
