export const environment = {
  production: true,
  apiUrl: 'https://admin.corp.biz-trip.kz/api/v1'
};
