export interface MobilePage {
  text: string;
  backBtn: string;
  isNotification?: boolean;
}
